﻿using System;
using System.Timers;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace Safeway_SMS_Feature
{
    class Program
    {
        static void Main(string[] args)
        {
            String passenger1;
            String friend_num;

            Console.WriteLine("Welcome to Safeway. The Rideshare Rescue.");
            Console.WriteLine("Enter Your First and Last Name:");
            passenger1 = Console.ReadLine();


            Console.WriteLine("Enter the phone number for your friend to notify upon your arrival:");
            friend_num = Console.ReadLine();

            Send_SMS(passenger1, friend_num); //calls SMS method passing in passenger and friend info.
        }

        //method to decide when to send SMS to friend
    


        //method to send message to friend
        static void Send_SMS(string pass_name, string f_num) {
            
            const string accountSid = "ACd551f7fc4ef4d1851647e89b430f8cc7"; //Twilio Account info
            const string authToken = "9040c352dd01318d5c60cf1cbb225bee";

            TwilioClient.Init(accountSid, authToken);

            var message = MessageResource.Create(
                body: pass_name + " has arrived at their destination safely",
                from: new Twilio.Types.PhoneNumber("+17206139644"),
                to: new Twilio.Types.PhoneNumber(f_num)
            );

            Console.WriteLine(message.Sid);
        }
    }
}